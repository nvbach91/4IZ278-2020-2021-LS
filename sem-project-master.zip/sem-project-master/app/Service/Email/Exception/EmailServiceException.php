<?php
declare(strict_types=1);

namespace App\Service\Email\Exception;


class EmailServiceException extends \Exception
{

}