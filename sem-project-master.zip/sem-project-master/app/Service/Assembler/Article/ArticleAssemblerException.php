<?php
declare(strict_types=1);

namespace App\Service\Assembler\Article;


use Exception;

class ArticleAssemblerException extends Exception
{

}